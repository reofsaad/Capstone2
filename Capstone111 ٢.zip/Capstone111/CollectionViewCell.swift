//
//  CollectionViewCell.swift
//  Capstone111
//
//  Created by Anaal Albeeshi on 15/02/1444 AH.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    // var imageView =
    
    @IBOutlet weak var ImageView: UIImageView!
}
